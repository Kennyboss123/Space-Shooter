using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerManner : MonoBehaviour
{
    [SerializeField] Rigidbody2D _rb;
    [SerializeField] Manner manner;
    float moveSpeed = 10f;
    float moveX;
    // Start is called before the first frame update
    void Start()
    {
        manner.SpawnManner();
        _rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        MovePlayer();
    }

    public void MovePlayer()
    {
        moveX = Input.GetAxis("Horizontal");
        _rb.velocity = new Vector3(moveX * moveSpeed, 0f, 0f); 
    }
}

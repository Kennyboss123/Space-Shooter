using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Manner : MonoBehaviour
{
    [SerializeField] GameObject mannerPrefab;
    bool _isGameOver = false;
    public void SpawnManner()
    {
        Instantiate(mannerPrefab, new Vector3(Random.Range(-8f, 8f), 6f, 0f), Quaternion.identity);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player" && !_isGameOver)
        {
            SpawnManner();
            Destroy(gameObject);
        }
        else if (collision.gameObject.tag == "Ground")
        {
            _isGameOver = true;
            Debug.Log("You are done");
        }
    }
}

using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    int _moveSpeed = 10;
    int _rotateSpeed = 200;
    [SerializeField] Rigidbody2D rb;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }
    void Update()
    {
        RotatePlayer();
        Moveplayer();
    }
    private void Moveplayer()
    {
        if (Input.GetKey(KeyCode.W))
        {
            transform.Translate(new Vector2(0f, _moveSpeed) * Time.deltaTime, Space.Self);
        }
    }
    void RotatePlayer()
    {
        if (Input.GetKey(KeyCode.A))
        {
            transform.Rotate(new Vector3(0f, 0f, _rotateSpeed) * Time.deltaTime, Space.Self);
        }
        else if (Input.GetKey(KeyCode.D))
        {
            transform.Rotate(new Vector3(0f, 0f, -_rotateSpeed) * Time.deltaTime, Space.Self);
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Collectibles : MonoBehaviour
{
    float cherriesCount = 0;
    [SerializeField] private TextMeshProUGUI score;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag == "Collectibles")
        {
            Destroy(collision.gameObject);
            cherriesCount += 20;
            score.text = "Cherries: " + cherriesCount;
        }
    }
}

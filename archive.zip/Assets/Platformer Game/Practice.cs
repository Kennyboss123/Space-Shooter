using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Practice : MonoBehaviour
{
    [SerializeField] Rigidbody2D rb;
    [SerializeField] float moveSpeed = 100f;
    [SerializeField] float force = 100f;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        Move();
    }

    private void Move()
    {
        float XMove = Input.GetAxis("Horizontal");
        rb.velocity = new Vector2 (XMove * moveSpeed, rb.velocity.y);

        if(Input.GetKey(KeyCode.Space))
        {
            rb.AddForce(new Vector2 (rb.velocity.x, force));
        }
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Enemy")
        {
            Destroy(gameObject);
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    [SerializeField] float moveSpeed = 100f;
    [SerializeField] GameObject[] waypoints;
    [SerializeField] private int currentWaypoint = 0;

    private void Start()
    {

    }
    private void Update()
    {
        MovePosition();
    }

    private void MovePosition()
    {
        float step = moveSpeed * Time.deltaTime;
        if (Vector2.Distance(waypoints[currentWaypoint].transform.position, transform.position) < .1f)
        {
            currentWaypoint++;
            if(currentWaypoint >= waypoints.Length)
            {
                currentWaypoint = 0;
            }
        }
        transform.position = Vector2.MoveTowards(transform.position, waypoints[currentWaypoint].transform.position, step);
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Enemy")
        {
            Destroy(gameObject);
        }
    }


    /*public void MoveToWayPoint()
    {
        float step = moveSpeed * Time.deltaTime;
        Timer -= Time.deltaTime;

        if (inStartPoint && Timer <= 0)
        {
            transform.position = Vector2.MoveTowards(transform.position, targetPosition.position, step);
            if (Vector2.Distance(transform.position, targetPosition.position) < 0.2)
            {
                inStartPoint = false;
                inEndPoint = true;

                Timer = 1f;
            }
        }

        if (inEndPoint && Timer <= 0)
        {
            transform.position = Vector2.MoveTowards(transform.position, targetPosition2.position, step);
            if (Vector2.Distance(transform.position, targetPosition2.position) < 0.2)
            {
                inStartPoint = true;
                inEndPoint = false;

                Timer = 1f;
            }
        }
    }*/
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    [SerializeField] GameObject enemyPrefab;
    [SerializeField] GameObject playerController;
    float enemyHealth = 100f;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(SpawnEnemy());
    }

    // Update is called once per frame
    void Update()
    {

    }
    IEnumerator SpawnEnemy()
    {
        GameObject Enemy = Instantiate(enemyPrefab, new Vector2(Random.Range(8, -8), 4f), Quaternion.identity);
        yield return new WaitForSeconds(1f);
    }

    void ReduceLife()
    {
        GetComponent<Health>().TakeHit(20);
        if(enemyHealth <= 0)
        {
            Destroy(enemyPrefab);
        }
    }
}

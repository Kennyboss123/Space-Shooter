using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [SerializeField] Rigidbody2D _rb;
    [SerializeField] GameObject laser;
    [SerializeField] Transform laserSpawnPoint;
    [SerializeField] Transform laserHolder;
    [SerializeField] EnemyController enemyController;
    float _rotateSpeed = 1f;
    float _moveSpeed = 5f;
    Vector2 _offset;
    bool _canShoot = true;
    void Start()
    {
        _rb = GetComponent<Rigidbody2D>();
    }
    void Update()
    {
        RotatePlayer();
        SpawnBullet();
    }

    private void RotatePlayer()
    {
        if(Input.GetKey(KeyCode.W))
        {
            transform.Translate(new Vector2(0, _moveSpeed) * Time.deltaTime, Space.Self);
        }
        if(Input.GetKey(KeyCode.A)) 
        {
            transform.Rotate(new Vector3(0, 0, _rotateSpeed), Space.Self);
        }        
        if(Input.GetKey(KeyCode.D)) 
        {
            transform.Rotate(new Vector3(0, 0, -_rotateSpeed), Space.Self);
        }
    }

    void SpawnBullet()
    {
        if (Input.GetKeyDown(KeyCode.Space) && _canShoot)
        {
            StartCoroutine(Fire());
        }
    }
    IEnumerator Fire()
    {
        _canShoot = false;
        GameObject Laser = Instantiate(laser, laserSpawnPoint.position, laserSpawnPoint.rotation, laserHolder);
        Laser.GetComponent<Rigidbody2D>().velocity = new Vector2(0f,-laserSpawnPoint.position.y * _moveSpeed);
        yield return new WaitForSeconds(.1f);
        Destroy(Laser, 3f);
        _canShoot = true;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Enemy")
        {
            Destroy(gameObject);
        }
    }
}
